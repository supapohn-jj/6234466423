/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab10_2;

/**
 *
 * @author This PC
 */
public class Hybrid extends Bus implements Electric,LiquidFuel {
    private double voltage;
    private double range;
    private int emissionTier;
    public Hybrid(double range,int emissionTier,double voltage,int capacity,double cost){
        super(capacity,cost);
        this.range=range;
        this.voltage=voltage;
        this.emissionTier=emissionTier;
        if(this.voltage<LOW_VOLTAGE)
            this.voltage=LOW_VOLTAGE;
        else if(this.voltage>HEIGHT_VOLTAGE)
            this.voltage=HEIGHT_VOLTAGE;
        
    }
    public double getAccel(){
        return 4.0;
    }
    public double getRange(){
        return range;
    }
    public double getVoltage(){
        return voltage;
    }
    public int getEmissionTier(){
        return emissionTier;
    }
}
