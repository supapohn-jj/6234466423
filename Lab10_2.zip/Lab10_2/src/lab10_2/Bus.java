/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab10_2;

/**
 *
 * @author This PC
 */
public abstract class Bus {
    private int id;
    private int capacity;
    private double cost;
    private static int nextId=1;
    public Bus(int capacity,double cost){
        this.capacity=capacity;
        this.cost=cost;
        id=nextId++;
    }
    public abstract double getAccel();
    public final int getId(){return id;}
    public int grtCapacity(){return capacity;}
    public double getCoast(){return cost;}
    

    
}
