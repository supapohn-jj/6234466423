/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab10_2;

import java.util.ArrayList;

/**
 *
 * @author This PC
 */
public class BusTester {
     public static void main(String[] args) {
        // TODO code application logic here
        ArrayList<Bus> arr = new ArrayList<Bus>();
        arr.add(new Hybrid(150,1,600,45,1.2));
        arr.add(new CNGBus(200,2,50,1));
        
        for(int i = 0;i < arr.size();i++){
            System.out.println("ID: "+arr.get(i).getId());
            if(arr.get(i) instanceof CNGBus){
                CNGBus bus = (CNGBus) arr.get(i);
                System.out.println("Emission Tier: "+bus.getEmissionTier());
            }
            else if(arr.get(i) instanceof Hybrid){
                Hybrid bus = (Hybrid) arr.get(i);
                System.out.println("Emission Tier: "+bus.getEmissionTier());
            }
            System.out.println("Accel: "+arr.get(i).getAccel());
        }
    }

}
