/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3_2;

/**
 *
 * @author USER
 */
public class LetterPrinter {
    public static void main(String[] args) {
        // TODO code application logic here
        Letter text = new Letter(" Jade","\nClarisa");
        text.adLine("\n We must find Simon quickly. \n He might be in danger. \n");
        System.out.print(text.getText());
    }
}
