/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package car;

/**
 *
 * @author This PC
 */
public class Truck extends Car {
    private double M_weight;
    private double weight;
    public Truck(double gas,double efficiency,double M_weight,double weight){
        super(gas,efficiency);
        this.M_weight=M_weight;
        this.weight = weight;
        if (this.M_weight>this.weight) {
            this.weight = M_weight;
        }

    }
    @Override
    public void drive(double distance)
    {
        double efficiencyT = super.getEfficiency();
        double amountGas ;
        
        if (weight<1) {
            amountGas = distance/efficiencyT;
        }
        else if (weight<=10) {
            amountGas = distance/efficiencyT*1.1;
        }
        else if (weight<=20) {
            amountGas = distance/efficiencyT*1.2;
        }
        else {
            amountGas = distance/efficiencyT*1.3;
        }
        if (amountGas<=gas) {
            gas = gas-amountGas;
        }
        else {
            System.out.println("You cannot drive too far, please add gas");
        }
    
    }
        

        
        
    
    
    
}
