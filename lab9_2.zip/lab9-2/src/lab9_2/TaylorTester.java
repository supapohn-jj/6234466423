/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab9_2;

/**
 *
 * @author This PC
 */
public class TaylorTester {
    public static void main(String[] args) {
        // TODO code application logic here
        expo exp = new expo(7, 1);
        exp.printValue();
        sine sn = new sine(7, Math.PI/4);
        sn.printValue();
        cosine cosn = new cosine(7, 1);
        cosn.printValue();
    }

}
