/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab9_2;

/**
 *
 * @author This PC
 */
public class expo extends Taylor{
    public expo(int k,double x){
        this.setIter(k);
        this.setValue(x);
    }
    
    @Override
    public void printValue(){
        System.out.println("Value from Math.exp() is "+Math.exp(this.getValue()));
        System.out.println("Approximated value is "+this.getApprox());
    }
    @Override
    public double getApprox() {
        double sum = 0;
        for(int n = 0;n <= this.getIter();n++){
            sum += (Math.pow(this.getValue(),n))/this.factorial(n);
        }
        return sum;
    }

}
