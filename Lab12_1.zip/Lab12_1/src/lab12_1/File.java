/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab12_1;
import java.io.*;
import java.util.Scanner;

/**
 *
 * @author This PC
 */
public class File {

    public static void main(String[]args) throws Exception{
        int sum = 0;
        int lines = 0;
        int words = 0;
        Scanner sc = new Scanner(System.in);
        String txt = sc.nextLine();
        PrintWriter txtFile = new PrintWriter("text.txt");
        
        //while loop 
        while(!(txt.equals("quit"))){
            txtFile.println(txt);
            txt = sc.nextLine();
        }
        
        txtFile.close();
        java.io.File file = new java.io.File("text.txt");
        Scanner read = new Scanner(file);
        
        while(read.hasNextLine()){
            String line = read.nextLine();
            sum+=line.length();
            words++;
            lines++;
            for(int i = 0;i<line.length();i++){
                if(line.charAt(i)==' ')
                    words++;
            }
        }
        read.close();
        
        System.out.println("Total characters : "+sum);
        System.out.println("Total words : "+words);
        System.out.println("Total lines : "+lines);
        
        
    }

    
}
