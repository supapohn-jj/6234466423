/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4_2;

/**
 *
 * @author USER
 */
public class DigitExtractor {
    public int num;
    public DigitExtractor(int anInteger){
        num = anInteger;
    }
    public int nextDigit(){
        int anInt = num%10;
        num = num/10;
        return anInt;
       }
}
