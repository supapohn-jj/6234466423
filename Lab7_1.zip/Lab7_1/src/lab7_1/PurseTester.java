/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab7_1;

/**
 *
 * @author USER
 */
public class PurseTester {
    public static void main(String[]args){
        Purse purse1 = new Purse();
        purse1.addCoin("Quarter");
        purse1.addCoin("Nickle");
        purse1.addCoin("Dime");
          Purse other = new Purse();
        other.addCoin("Quarter");
        other.addCoin("Dim");
        purse1.sameCoin(purse1);
        System.out.println(purse1.toString());
       System.out.println(other.toString());
        System.out.println(purse1.reverse());
        System.out.println(purse1.toString());
        System.out.println(other.sameCoin(purse1));
        System.out.println(other.sameContent(purse1));
    }
}
