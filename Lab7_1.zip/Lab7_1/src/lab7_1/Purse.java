/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab7_1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

/**
 *
 * @author USER
 */
public class Purse {
    ArrayList<String> listCoinName = new ArrayList<String>();
    public Purse(){
      
    }
    public void addCoin(String coinName){
        listCoinName.add(coinName);
        
    }
    @Override
    public String toString(){
        String lcn = String.join(",",listCoinName);
        return lcn;
    }
    public ArrayList<String> reverse(){
        Collections.reverse(listCoinName);
        return listCoinName;
    }
    public void transfer(Purse other){
       other.listCoinName.addAll(listCoinName);
       listCoinName.clear();
    }
    public boolean sameContent(Purse other){
        boolean isEqual;
        if(other.listCoinName.equals(other)){  isEqual = true;}
        else{ isEqual = false;}
        return isEqual;
        
    }
    public boolean sameCoin(Purse other){
       boolean isEqual;
       isEqual = other.listCoinName.containsAll(listCoinName);
       return isEqual;
   }
}
