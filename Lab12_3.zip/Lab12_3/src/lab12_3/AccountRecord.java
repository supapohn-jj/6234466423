/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab12_3;

/**
 *
 * @author This PC
 */
public class AccountRecord {
    private int acctNO;
    private String name;
    private double balance;
    private int transCnt = 0;
    // count how many times that this account do transaction
    public AccountRecord(int acctNO,String name,double balance){
        this.acctNO = acctNO;
        this.balance = balance;
        this.name = name;
    }
    public int getAcctNO(){
        return acctNO;
    }
    public double getBalance(){
        return balance ;
    }
    public String getName(){
        return name;
    }
    public int getTransCnt(){
        return transCnt;
    }
    public void combine(TransactionRecord t) {
        balance += t.getamountOfTransaction();
        transCnt++;
    }

}
