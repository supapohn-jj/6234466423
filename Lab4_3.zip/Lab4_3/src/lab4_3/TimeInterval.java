/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4_3;
import java.lang.Math;
/**
 *
 * @author USER
 */
public class TimeInterval {
    private int beGin,end,hourBegin,minuteBegin,hourEnd,minuteEnd
            ,beginIng,ending;
    public TimeInterval(int beginTime , int endingTime){
        beGin = beginTime;
        end = endingTime;
        hourBegin = (beGin/100)*60;
        minuteBegin = beGin%100;
        hourEnd = (end/100)*60;
        minuteEnd = end%100;
        beginIng =hourBegin + minuteBegin;
        ending = hourEnd +minuteEnd;
    }
    public int getHours(){
        return (int) (Math.abs(ending - beginIng)/60);
    }
    public int getMinutes(){
        return Math.abs((((ending-beginIng)/60)*60)-(ending-beginIng));
       
    }
}
