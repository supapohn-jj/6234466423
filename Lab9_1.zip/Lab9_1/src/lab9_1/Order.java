/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab9_1;
import java.util.ArrayList;
/**
 *
 * @author This PC
 */
public class Order {
    public static int cntOrder = 0;
    public int id;
    private Customer c;
    private ArrayList<Pizza> p = new ArrayList<Pizza>();
    private double r=0;
    public Order(Customer c){
        cntOrder++;
        id = cntOrder;
        this.c = c;
    }

    public void addPizza(Pizza piz){
        p.add(piz);
    }
    
    public String getOrderDetail(){
        double cost=0;
        String detail = "";
        
        if(c instanceof GoldCustomer){
            GoldCustomer g = (GoldCustomer) c;
            detail = "Order id : "+id+"\n"+c.getName()+" tel : "+c.getTel()+" discount : "+g.getDiscount()+"\n";
        }
        else{
            detail = "Order id : "+id+"\n"+c.getName()+" tel : "+c.getTel()+"\n";
        }
        
        for(int j = 0;j < p.size();j++){
            if(p.get(j) instanceof PizzaSpecial){
                PizzaSpecial s = (PizzaSpecial) p.get(j);
                detail += p.get(j).getName()+" price : "+p.get(j).getPrice()+" special : "+s.getSpecial()+"\n";
                cost+=p.get(j).getPrice();
            }
            else{
                detail += p.get(j).getName()+" price : "+p.get(j).getPrice()+"\n";
                cost+=p.get(j).getPrice();
            }
            
        }
        if(c instanceof GoldCustomer){
                    GoldCustomer g = (GoldCustomer) c;
                    cost -= (cost*g.getDiscount())/100;
                }
        detail += "Total pieces : "+p.size()+"\nTotal cost : "+cost;
        
        r += cost;
        return detail;
    }
    
    public double calculatePayment(){
        return r;
    }


    
}
