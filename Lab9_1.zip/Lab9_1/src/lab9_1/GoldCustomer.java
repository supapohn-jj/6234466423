/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab9_1;

/**
 *
 * @author This PC
 */
public class GoldCustomer extends Customer{
    private double discount=0;
    public GoldCustomer(String name,String tel,double discount){
        super(name,tel);
        this.discount=discount;
    }
    public double getDiscount(){
        return discount;
    }
    public String toString(){
        return "name :"+ this.getName()+"\n"
                +"Tel :"+this.getTel()+"\n"+
                "discount :"+discount;
    }
    
}
