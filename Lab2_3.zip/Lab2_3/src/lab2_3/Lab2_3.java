/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2_3;
import java.util.Calendar;
import java.util.GregorianCalendar;
/**
 *
 * @author USER
 */
public class Lab2_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       GregorianCalendar cal = new GregorianCalendar();
       cal.add(Calendar.DAY_OF_MONTH,100);
       int dayOfMonth = cal.get(Calendar.DAY_OF_MONTH);
       int month = cal.get(Calendar.MONTH);
       int year = cal.get(Calendar.YEAR);
       int weekDay = cal.get(Calendar.DAY_OF_WEEK);
        System.out.print(weekDay+" ");
        System.out.print(dayOfMonth+" ");
        System.out.print(month+" ");
        System.out.println(year);
       GregorianCalendar myBirthday = new GregorianCalendar(2001,Calendar.APRIL,27);
       myBirthday.add(Calendar.DAY_OF_MONTH,10000);
       int dayOfMonthB = myBirthday.get(Calendar.DAY_OF_MONTH);
       int monthB = myBirthday.get(Calendar.MONTH);
       int yearB = myBirthday.get(Calendar.YEAR);
       int weekDayB = myBirthday.get(Calendar.DAY_OF_WEEK);
        System.out.print(weekDayB+" ");
        System.out.print(dayOfMonthB+" ");
        System.out.print(monthB+" ");
        System.out.print(yearB);

    }
    
}
