/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3_3;

/**
 *
 * @author USER
 */
public class CashRegisterTester {
    public static void main(String[] args) {
        // TODO code application logic here
        CashRegister tax = new CashRegister(0.07);
        tax.recordPurchase(50);
        tax.recordPurchase(10);
        tax.recordTaxPurchase(20);
        tax.enterPayment(100);
        System.out.print("Your change is ");
        System.out.println(tax.giveChange());
    }
}
