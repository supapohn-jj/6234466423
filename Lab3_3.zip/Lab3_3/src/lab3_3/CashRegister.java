/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3_3;

/**
 *
 * @author USER
 */
public class CashRegister {
    private double total1;
    private double total2;
    private double payment ;
    private double taxrate;
    private double tax;
    
    public CashRegister(double rate){
        taxrate = rate;
    }
    public void enterPayment(int input){
        payment += input;
    }
    public void recordPurchase(double  price1){
        total1+=price1;
    }
    public void recordTaxPurchase(double price2){
        tax = price2*taxrate;
        total2 += price2+tax;
        tax=0;
    }
    public double getTotalTax(){
        return taxrate;
    }
    public double giveChange(){
        double change = payment-(total1+total2);
        total1=0;
        total2=0;
        payment=0;
        return change;
    }
    
    
}
