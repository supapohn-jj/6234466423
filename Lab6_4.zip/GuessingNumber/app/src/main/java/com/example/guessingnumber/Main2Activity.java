package com.example.guessingnumber;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;
public class Main2Activity extends AppCompatActivity implements View.OnClickListener{

    public static final  int MAX_NUMBER =100;
    public static final Random RANDOM = new Random();
    private TextView TextView2;
    private EditText EnterNumber;
    private Button button2;
    private int numToFind,trie;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        TextView2 = (TextView) findViewById(R.id.textView2);
        EnterNumber=(EditText) findViewById(R.id.EnterNumber);
        button2=(Button) findViewById(R.id.button2);
        button2.setOnClickListener(this);

        newGame();
    }
    @Override
    public void onClick(View view){
        if(view==button2){validate();}
    }
    private void validate(){
        int n = Integer.parseInt(EnterNumber.getText().toString());
        trie++;

        if(n==numToFind) {
           // Toast.makeText(this,"You Won"+numToFind+
                   // "in"+trie+"tries",Toast.LENGTH_SHORT).show();
            Button Start = (Button) findViewById(R.id.startbut);
            Start.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    Intent intent = new Intent(Main2Activity.this, Main3Activity.class);
                    startActivity(intent);
                }
            });
            newGame();

        }
        else if(n>numToFind) {
            TextView2.setText("too high");

        }
        else if(n<numToFind){TextView2.setText("too loe");}
    }
    private void newGame(){
        numToFind=RANDOM.nextInt(MAX_NUMBER);
        TextView2.setText(R.string.start_textView2);
        EnterNumber.setText("");
        trie =0;
    }
}
