/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question;
import java.util.ArrayList;
/**
 *
 * @author This PC
 */
public class ChoiceQuestion extends Question {
    private ArrayList<String>choices = new ArrayList<String>();
    public ChoiceQuestion(String text){
        this.text=text;
    }
    public void addChoice(String choice,boolean correct){
        choices.add(choice);
        if(correct == true){this.setAnswer(choice);} 
    }
    @Override
    public void display(){
        System.out.println(text);
        for(int i=0;i<choices.size();i++){
            System.out.println((i+1)+":"+choices.get(i));
        }
        
    }
    @Override
    public boolean checkAnswer(String response){
        for(int i =0; i<choices.size();i++){
            if(answer.equals(choices.get(i)))
                return true;
        }
        
        return false;
    }
}

