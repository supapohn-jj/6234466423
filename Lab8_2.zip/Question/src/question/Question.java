/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question;
import java.util.ArrayList;
/**
 *
 * @author This PC
 */
public class Question {
    protected String text;
    protected String answer;
    public Question(){
        answer = "";
    }
    public Question(String text){
        this.text=text;
    }
    public void setText(String newText){
        text = newText;
    }
    public void setAnswer(String newAnswer){
        answer =newAnswer;
    }
    public boolean checkAnswer(String response){
        if(response.equals(answer))
            return true;
        return false;
    }
    public void display(){
        System.out.println(text);
    }
            
                    
            
    
    
}
