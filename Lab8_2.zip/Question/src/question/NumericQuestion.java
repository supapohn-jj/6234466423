/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question;
import java.lang.Math;
/**
 *
 * @author This PC
 */
public class NumericQuestion extends Question{
    public NumericQuestion(String text){
        this.text=text;
    }
    @Override
    public boolean checkAnswer(String response){
        double r =Double.parseDouble(response);
        double ans = Double.parseDouble(answer);
        if(Math.abs(r-ans)<0.01)
            return true;
        return false;
    }
}
