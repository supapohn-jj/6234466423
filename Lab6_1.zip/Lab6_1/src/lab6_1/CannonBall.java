/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab6_1;

/**
 *
 * @author USER
 */
public class CannonBall {
    private double simS,simT,simV,initV;
    public static final double g=9.81;
    public CannonBall(double v0){
       initV=v0;
       simV=v0;
    }
    public void simulateFlight(){
        while(true){
            double t =0,s=simS,v=simV;
            simT++;
            while(t<100){
                s=s+v*0.01;
                v=v-g*0.01;
                t++;
            }
            if(v<=0){
                simT--;
                System.out.printf("final distance :%.3f\t",this.getSimulateDistance());
                System.out.printf("Total time : %.2f\n",this.getSimulateTime());
                break;
            }
            simV=v;simS=s;
            System.out.printf("Distance on %d sec :%.3f \n",(int)simT,simS,"\n");
                    
        }
    }
    public double calculusFlight(double t){
       return (-0.5)*g*simT*simT+initV*simT;
    }
    public double getSimulateTime(){
        return simT;
    }
    public double getSimulateDistance(){
        double t=0,s=simS,v=simV;
        while(t<100){
            s=s+v*0.01;
            v=v-g*0.01;
            t++;
            if(v<=0){
                simT=simT+t*0.01;
                return simS;
            }
            simS=s;
        }
        return 0;
    }
}
