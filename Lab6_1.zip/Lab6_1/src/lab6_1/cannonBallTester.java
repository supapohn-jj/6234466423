/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab6_1;

/**
 *
 * @author USER
 */
public class cannonBallTester {
    public static void main(String[] args){
        CannonBall ball = new CannonBall(100);
        ball.simulateFlight();
        System.out.print(ball.calculusFlight(ball.getSimulateTime()));
    }
}
