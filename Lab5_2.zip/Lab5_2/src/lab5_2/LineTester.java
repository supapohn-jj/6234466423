/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab5_2;
import java.awt.geom.Point2D;
/**
 *
 * @author USER
 */
public class LineTester {
    public void print(Line l1,Line l2){
        Point2D.Double line = l1.getIntersectionPoint(l2);
        System.out.println("Are the two lines equals?: "+l1.equals(l2));
        System.out.println("Are the two lines parallel?: "+l1.isParallel(l2));
        System.out.println("Do the two lines intersect?: "+l1.isIntersect(l2));
        if(line != null){System.out.printf("Point of intersection: %.2f,%.2f \n",line.getX(),line.getY());}}
    
    public static void main(String[] args) {
        LineTester test = new LineTester();
        Line l1 = new Line(-2,1,1-2);
        Line l2 = new Line(-6,-2,-2,0);  
        test.print(l1, l2);
    }

  }
