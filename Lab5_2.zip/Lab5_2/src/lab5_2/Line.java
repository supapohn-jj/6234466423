/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab5_2;
import java.awt.geom.Point2D;
import java.awt.geom.Point2D.Double ;
/**
 *
 * @author USER
 */
public class Line {
    private boolean XCh = false;
    private double s,c,X;
    Point2D.Double L1,L2;
    public Line(double x,double y,double m){
        s=m;
        c=y-(m*x);
    }
    public Line(double x1,double y1,double x2,double y2){
       L1=new Point2D.Double(x1,y1);
       L2=new Point2D.Double(x2,y2);
       s=(y2-y1)/(x2-x1);
       c=y1-(s*x1);
    }
    public Line(double m,double b){
        s=m;
        c=b;
    }
    public Line(double a){
        X=a;
        c=0;
        s=1;
        XCh = true;
    }
    public boolean isParallel(Line line){
        if (this.s==line.s){return true;}
        else{return false;}
    }
    public boolean equal(Line line){
        if(this.s==line.s && this.c==line.c){return true;}
        else {return false;}
    }
    public boolean isIntersect(Line line){
        if(this.isParallel(line)==false){return true;}
        else{return false;}
    }
     public Point2D.Double getIntersectionPoint(Line line){
        if(this.isParallel(line)==false){
            if(this.XCh == true){
                double x = this.X ;
                double y = (line.s*x)+line.c;
                Point2D.Double point = new Point2D.Double(x,y);
                return point;}
                
            
            else if(line.XCh==true){
                double x = line.X ;
                double y = (this.s*x)+this.c;
                Point2D.Double point = new Point2D.Double(x,y);
                return point;
            
            }
            
            else if(this.s==0){
                double x = (this.c-line.c)/line.s ;
                double y = this.c;
                Point2D.Double point = new Point2D.Double(x,y);
                return point;
                
            }
            
            else if(line.s==0){
                double x = (line.c-this.c)/this.s;
                double y = line.c;
                Point2D.Double point = new Point2D.Double(x,y);
                return point; }
            
            else if(this.s==0 && line.XCh==true){
                double x = line.X;
                double y = this.c;
                Point2D.Double point = new Point2D.Double(x,y);
                return point; }
            
            else if(line.s==0 && this.XCh==true){
                double x = this.s;
                double y = line.c;
                Point2D.Double point = new Point2D.Double(x,y);
                return point; }
            
            
            
            
            else{
                double x = (-1)*(this.c-line.c)/(this.s-line.s) ;
                double y = (this.s*x)+this.c ;
                Point2D.Double point = new Point2D.Double(x,y);
                return point;}
        
    }
        
        else{return null;}
        
    }

  }






