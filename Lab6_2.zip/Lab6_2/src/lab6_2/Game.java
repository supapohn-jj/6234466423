/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab6_2;
import java.util.Random;
import java.lang.Math;
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class Game {
    private int comScore,uScore,score;
    Random rsp = new Random();
    //int comRand = rsp.nextInt(3);
    /*Scanner sc = new Scanner(System.in);
    int userInput = sc.nextInt();*/
   
    public Game(){
        score =Math.abs(uScore-comScore);
    }
    public int play(){
        
        while(Math.abs(uScore-comScore)<2){
            //int score=0,uScore=0,comScore=0;
            Scanner sc = new Scanner(System.in);
            System.out.print("Enter 0 for ROCK,1 for SCISSORS,2 for PAPER :" );
            int userInput = sc.nextInt();
            if(userInput==0) {
                System.out.print("You enter :ROCk \n");
                if(rsp.nextInt(3)==0){
                    System.out.print("Computer : ROCK \nIt's a tie .");
                    score = score;
                }
                else if(rsp.nextInt(3)==1){
                    System.out.print("Computer : SCOSSORS \nYou win! ");
                    uScore++;
                }
                else if(rsp.nextInt(3)==2){
                    System.out.print("Computer : PAPER \nyou lose! \n");
                    comScore++;
                }   
            }
            if(userInput==1) {
                System.out.print("You enter :SCISSORS \n");
                if(rsp.nextInt(3)==0){
                    System.out.print("Computer : ROCK \nYou lose! .\n");
                    comScore++;
                }
                else if(rsp.nextInt(3)==1){
                    System.out.print("Computer : SCISSORS \nIt's a tie\n");
                    score = score;
                }
                else if(rsp.nextInt(3)==2){
                    System.out.print("Computer : PAPER \nyou win! \n");
                    uScore++;
                }   
            }
            if(userInput==2) {
                System.out.print("You enter :PAPER \n");
                if(rsp.nextInt(3)==0){
                    System.out.print("Computer : ROCK \n you win! .\n");
                    uScore++;
                }
                else if(rsp.nextInt(3)==1){
                    System.out.print("Computer : SCOSSORS \nYou lose! \n");
                    comScore++;
                }
                else if(rsp.nextInt(3)==2){
                    System.out.print("Computer : PAPER \n It's a tie  \n");
                    score = score;
                }   
            }
        }
        if(Math.abs(comScore-uScore)==2){
            if(comScore>uScore){
                System.out.print("Too bad you lose!\n");
            }
            else{ System.out.print("Congrat! you win\n");}
        }
        System.out.print("your score :"+uScore+"\n");
        System.out.print("Computer score :");
        return comScore;
    }
}
