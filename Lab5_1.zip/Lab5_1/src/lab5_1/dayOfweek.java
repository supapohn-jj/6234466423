/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab5_1;

/**
 *
 * @author USER
 */
enum Days{
    SUNDAY,MONDAY,TUESDAY,WEDNESDAY,THURSDAY,FRIDAY,SATURDAY;
}
public class dayOfweek{
    int year,month,dayOfMonth;
    public dayOfweek(int dy,int mth,int y){
        month=mth;
        year = y;
        dayOfMonth = dy;
    }
    public Days getDayOfWeek(){
        if(month==1){month=13;year=year-1;}
        if (month==2){month=14;year=year-1;}
        int h,q=dayOfMonth,k=year%100,j=year/100,m=month;
        Days day = null;
        h = (q+((26*(m+1))/10)+k+(k/4)+(j/4)+(5*j))%7 ;
        
        switch(h){
            case 0:day=Days.SATURDAY;break;
            case 1:day=Days.SUNDAY;break;
            case 2:day=Days.MONDAY;break;
            case 3:day=Days.TUESDAY;break;
            case 4:day=Days.WEDNESDAY;break;
            case 5:day=Days.THURSDAY;break;
            case 6:day=Days.FRIDAY;break;
        }
       return day;
    }
}
