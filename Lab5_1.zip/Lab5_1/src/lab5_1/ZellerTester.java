/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab5_1;
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class ZellerTester {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter Year(e.g.,2012) :");
        int year = sc.nextInt();
        System.out.print("Enter month(1-12) :");
        int m = sc.nextInt();
        System.out.print("Enter day of the month(1-31) :");
        int q = sc.nextInt();
        
        dayOfweek dw = new dayOfweek(q,m,year);
        System.out.print("Day of the week is : ");
        System.out.print(dw.getDayOfWeek()+"\n");
    }
}
