/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab6_3;
import java.util.Random;
/**
 *
 * @author USER
 */
public class CityGrid {
    private static int xCoor,yCoor,gridSize,n;
    private static int i;
    private boolean inCity;
    private int x,y;
    public CityGrid(int x, int y){
       this.xCoor=x/2;
       this.yCoor=y/2;
       this.x=x;
       this.y=y;
    }
    public boolean isInCity(){
        if ((xCoor<0 || xCoor>x) || (yCoor<0 || yCoor>y)){
            return false;
        }
        else{
            return true;
        }
    }
    public void walk(int step){
        Random rand = new Random();
        int stepRand =rand.nextInt(4);
        switch(stepRand){
            case 0 : xCoor++;break;
            case 1 : xCoor--;break;
            case 2 : yCoor++;break;
            case 3 : yCoor--;break;
        }
        
    }
    public void reset(){
        xCoor=x/5;yCoor=y/5;
    }
    public static void main(String[]args){
        CityGrid wm = new CityGrid(10,10);
        double ave=0;
        int max=0;
        for (int i=0 ; i<10000 ; i++){
            for (int j=0 ; j<1000 ; j++){
                if(wm.isInCity()){
                 wm.walk(1000);
                 ave++;
                }
                else{
                 wm.reset();
                 if(max<j){
                     max=j;
                 }
                 break;
                }
            }
        }
        
        System.out.printf("Average number of step that person can take and stiil in a city : %.2f ",ave/10000);
        System.out.println("\nMaximum number of step that a person can take and still in a city : "+max);
        


    }
}
