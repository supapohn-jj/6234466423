/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2_2;

/**
 *
 * @author USER
 */
public class Lab2_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
      String greeting = "Hello world!";
      greeting = greeting.replace("e","x");
      greeting = greeting.replace("o","y");
      greeting = greeting.replace("x","o");
      greeting =  greeting.replace("y","e");
      System.out.println(greeting);
    }
    
}
