/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab11_2;

/**
 *
 * @author This PC
 */
public abstract class Animal {
    String name;
    Animal(String name){this.name = name;}
    void setName(String name){this.name = name;}
    String getName(){return name;}
    public void walk(Object o){}
    public void run(Object o){}
    public void fly(Object o){}
    public void swim(Object o){}
}
