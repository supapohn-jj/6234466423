/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab10.pkg1;

/**
 *
 * @author This PC
 */
public class Subject implements Evaluation{
    private String subjName;
    private int[] score;
    public Subject(String subjName,int[] score){
        this.subjName=subjName;
        this.score=score;
    }
    @Override
    public double evaluate(){
        int s=0;
        int count=0;
        for(int i=0;i<score.length;i++){
            s+=score[i];
            count++;
        }
        double sum=s/count;
        return sum;
    }
    @Override
    public char grade(double sum){
        if(sum>=70){
            return 'p';
        }
        return 'F';
    }
    @Override
    public String toString(){
        return subjName;
    }
}