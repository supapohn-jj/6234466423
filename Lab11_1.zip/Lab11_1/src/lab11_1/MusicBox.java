/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab11_1;
import java.util.ArrayList;
/**
 *
 * @author This PC
 */
public class MusicBox implements SimpleQueue {
    private ArrayList<String> songQueue= new ArrayList<String>();
    public MusicBox(){
    }
    @Override
    public void enqueue(Object o){
        if(o instanceof String){
            String nameSong = (String) o;
            System.out.println(nameSong+" is added in queue");
            songQueue.add(nameSong);}

    }
    @Override
    public void dequeue(){
        System.out.println("now is playing "+songQueue.get(0));
        songQueue.remove(0);
    }
}
