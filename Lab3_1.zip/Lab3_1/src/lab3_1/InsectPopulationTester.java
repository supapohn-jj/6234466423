/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3_1;

/**
 *
 * @author USER
 */
public class InsectPopulationTester {
    public static void main(String[] args) {
        // TODO code application logic here
        InsectPopulation population = new InsectPopulation(10);
        population.breed();
        population.spray();
        System.out.print("Number of Insects : ");
        System.out.println(population.getNumber());
        population.breed();
        population.spray();
        System.out.print("Number of Insects : ");
        System.out.println(population.getNumber());
        population.breed();
        population.spray();
        System.out.print("Number of Insects : ");
        System.out.println(population.getNumber());
    }

    }
